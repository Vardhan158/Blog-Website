import React, { useState, useEffect } from "react";
import md5 from "md5";
import axios from "axios";
import { FaHeart, FaRegCommentDots } from "react-icons/fa";

const EditProfile = ({ userData, setUserData }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [description, setDescription] = useState("");
  const [profileImage, setProfileImage] = useState(null);
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [commentText, setCommentText] = useState({});

  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  // ✅ Gravatar fallback
  const getGravatar = (email) => {
    if (!email) return "/default-profile.png";
    const hash = md5(email.trim().toLowerCase());
    return `https://www.gravatar.com/avatar/${hash}?d=identicon`;
  };

  // ✅ Fetch profile data
  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("No authentication token found.");

      const res = await axios.get(`${API_URL}/api/user/profile`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const user = res.data.user || res.data;
      if (!user || !user.email) throw new Error("Invalid profile data received.");

      setName(user.name || user.username || "");
      setEmail(user.email || "");
      setDescription(user.description || "");

      if (user.profileImage) {
        setProfileImage(
          user.profileImage.startsWith("http")
            ? user.profileImage
            : `${API_URL}/uploads/${user.profileImage}`
        );
      } else {
        setProfileImage(getGravatar(user.email));
      }

      if (setUserData) setUserData(user);
      setError("");
    } catch (err) {
      console.error("Error fetching profile:", err);
      setError("Failed to load profile. Please make sure you’re logged in.");
    }
  };

  // ✅ Fetch blogs
  const fetchBlogs = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const res = await axios.get(`${API_URL}/api/blogs/user`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setBlogs(Array.isArray(res.data.blogs) ? res.data.blogs : []);
    } catch (err) {
      console.error("Error fetching blogs:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
    fetchBlogs();
  }, []);

  // ✅ Upload Profile Image
  const handleImageChange = async (e) => {
    if (!e.target.files?.[0]) return;
    const file = e.target.files[0];

    const formData = new FormData();
    formData.append("profileImage", file);

    try {
      const token = localStorage.getItem("token");
      const res = await axios.post(`${API_URL}/api/user/upload-profile`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      const user = res.data.user || {};
      const uploadedImage = user.profileImage || "";

      if (!uploadedImage) {
        alert("Image uploaded but backend did not return an image path.");
        return;
      }

      const imageUrl = uploadedImage.startsWith("http")
        ? uploadedImage
        : `${API_URL}/uploads/${uploadedImage}`;

      setProfileImage(imageUrl);
      localStorage.setItem("profileImage", imageUrl);
      if (setUserData) setUserData(user);
      alert("Profile picture updated!");
    } catch (err) {
      console.error("Error uploading profile image:", err);
      alert("Failed to upload image.");
    }
  };

  // ✅ Update Profile
  const handleProfileUpdate = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.put(
        `${API_URL}/api/user/update`,
        { name, description },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      const user = res.data.user;
      if (setUserData) setUserData(user);
      alert("Profile updated successfully!");
    } catch (err) {
      console.error("Error updating profile:", err);
      alert("Failed to update profile.");
    }
  };

  // ✅ Like / Unlike Blog
  const handleLike = async (blogId) => {
    try {
      const token = localStorage.getItem("token");
      await axios.put(`${API_URL}/api/blogs/like/${blogId}`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setBlogs((prev) =>
        prev.map((blog) =>
          blog._id === blogId
            ? {
                ...blog,
                likes: blog.likes.includes(userData._id)
                  ? blog.likes.filter((id) => id !== userData._id)
                  : [...blog.likes, userData._id],
              }
            : blog
        )
      );
    } catch (err) {
      console.error(err);
    }
  };

  // ✅ Add Comment
  const handleComment = async (blogId) => {
    if (!commentText[blogId]) return;
    try {
      const token = localStorage.getItem("token");
      await axios.post(
        `${API_URL}/api/blogs/comment/${blogId}`,
        { comment: commentText[blogId] },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setBlogs((prev) =>
        prev.map((blog) =>
          blog._id === blogId
            ? {
                ...blog,
                comments: [
                  ...blog.comments,
                  {
                    userId: userData._id,
                    userName: userData.name || "You",
                    comment: commentText[blogId],
                    createdAt: new Date(),
                  },
                ],
              }
            : blog
        )
      );

      setCommentText((prev) => ({ ...prev, [blogId]: "" }));
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen text-gray-600 text-lg">
        Loading profile...
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen text-gray-600">
        <p className="text-red-500 mb-4 font-medium">{error}</p>
        <button
          onClick={fetchProfile}
          className="bg-indigo-500 text-white px-4 py-2 rounded-md hover:bg-indigo-600 transition"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center px-4 py-10">
      {/* Profile Section */}
      <div className="bg-white shadow-lg rounded-3xl w-full max-w-5xl p-10 flex flex-col md:flex-row gap-10">
        {/* LEFT SIDE */}
        <div className="flex flex-col items-center md:w-1/2">
          <div
            className="w-40 h-40 rounded-full border-4 border-gray-300 shadow-md overflow-hidden cursor-pointer"
            onClick={() => document.getElementById("profileInput").click()}
          >
            <img
              src={profileImage || "/default-profile.png"}
              alt="Profile"
              className="w-full h-full object-cover"
            />
          </div>
          <input
            type="file"
            id="profileInput"
            className="hidden"
            accept="image/*"
            onChange={handleImageChange}
          />
          <input
            type="text"
            placeholder="Enter your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-4 text-center text-2xl font-semibold border-b border-gray-300 focus:outline-none focus:ring-1 focus:ring-indigo-400"
          />
          <p className="mt-2 text-gray-600">{email}</p>
        </div>

        {/* RIGHT SIDE */}
        <div className="flex flex-col justify-center md:w-1/2 space-y-6">
          <div>
            <label className="block text-gray-600 font-medium mb-2">Description</label>
            <textarea
              placeholder="Write something about yourself..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows="3"
              className="w-full px-4 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </div>

          <button
            onClick={handleProfileUpdate}
            className="w-full bg-indigo-500 text-white py-2 rounded-lg hover:bg-indigo-600 transition font-semibold"
          >
            Update Profile
          </button>
        </div>
      </div>

      {/* Blogs Section */}
      <div className="w-full max-w-5xl mt-10">
        <h2 className="text-2xl font-semibold text-center mb-8">Your Blogs</h2>
        {blogs.length === 0 ? (
          <p className="text-center text-gray-500">No blogs posted yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogs.map((blog) => (
              <div
                key={blog._id}
                className="p-6 bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-lg transition transform hover:-translate-y-1 duration-300"
              >
                <h3 className="text-lg font-semibold text-gray-800 mb-2">{blog.title}</h3>
                <p className="text-sm text-gray-500 mb-4">{blog.content.slice(0, 100)}...</p>

                <div className="flex justify-between items-center text-gray-600 text-sm mb-2">
                  <div
                    className="flex items-center gap-1 cursor-pointer"
                    onClick={() => handleLike(blog._id)}
                  >
                    <FaHeart
                      className={`text-red-500 ${
                        blog.likes.includes(userData._id) ? "fill-current" : ""
                      }`}
                    />{" "}
                    {Array.isArray(blog.likes) ? blog.likes.length : 0}
                  </div>
                  <div className="flex items-center gap-1">
                    <FaRegCommentDots className="text-green-500" />{" "}
                    {Array.isArray(blog.comments) ? blog.comments.length : 0}
                  </div>
                </div>

                {/* Comments */}
                <div className="mt-2 text-sm text-gray-700 space-y-1">
                  {Array.isArray(blog.comments) &&
                    blog.comments.map((c, idx) => (
                      <div key={idx} className="border-b border-gray-200 pb-1">
                        <span className="font-semibold">{c.userName || "Anonymous"}:</span>{" "}
                        {c.comment}
                      </div>
                    ))}
                </div>

                {/* Add comment */}
                <div className="flex gap-2 mt-2">
                  <input
                    type="text"
                    placeholder="Add a comment..."
                    value={commentText[blog._id] || ""}
                    onChange={(e) =>
                      setCommentText((prev) => ({ ...prev, [blog._id]: e.target.value }))
                    }
                    className="w-full px-2 py-1 border rounded"
                  />
                  <button
                    onClick={() => handleComment(blog._id)}
                    className="px-3 py-1 bg-indigo-500 text-white rounded hover:bg-indigo-600"
                  >
                    Post
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default EditProfile;
