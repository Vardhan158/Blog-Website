import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null); // success/error message state

  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    try {
      const res = await axios.post(`${API_URL}/auth/login`, formData);

      if (res.data.token) {
        localStorage.setItem("token", res.data.token);
        localStorage.setItem("username", res.data.username);

        // ✅ Show success message
        setMessage({
          type: "success",
          title: "Login Successful!",
          text: "Redirecting to dashboard...",
        });

        // Redirect after short delay
        setTimeout(() => {
          navigate("/home");
        }, 1500);
      }
    } catch (err) {
      console.error(err.response?.data || err);
      // ❌ Show error message
      setMessage({
        type: "error",
        title: "Login Failed!",
        text: err.response?.data?.message || "Invalid credentials.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center mt-20">
      {/* ✅ Message UI */}
      {message && (
        <div
          className={`bg-white inline-flex space-x-3 p-3 text-sm rounded border shadow-sm mb-4 ${
            message.type === "success"
              ? "border-green-200"
              : "border-red-200"
          }`}
        >
          {message.type === "success" ? (
            <svg
              width="18"
              height="18"
              viewBox="0 0 18 18"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M16.5 8.31V9a7.5 7.5 0 1 1-4.447-6.855M16.5 3 9 10.508l-2.25-2.25"
                stroke="#22C55E"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          ) : (
            <svg
              width="18"
              height="18"
              viewBox="0 0 18 18"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M9 0a9 9 0 1 1 0 18A9 9 0 0 1 9 0Zm0 13.5a.9.9 0 1 0 0-1.8.9.9 0 0 0 0 1.8Zm0-3.6a.9.9 0 0 0 .9-.9V5.4a.9.9 0 1 0-1.8 0v3.6a.9.9 0 0 0 .9.9Z"
                fill="#EF4444"
              />
            </svg>
          )}
          <div>
            <h3
              className={`font-medium ${
                message.type === "success"
                  ? "text-slate-700"
                  : "text-red-600"
              }`}
            >
              {message.title}
            </h3>
            <p className="text-slate-500">{message.text}</p>
          </div>
          <button
            type="button"
            aria-label="close"
            onClick={() => setMessage(null)}
            className="cursor-pointer mb-auto text-slate-400 hover:text-slate-600 active:scale-95 transition"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 14 14"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <rect
                y="12.532"
                width="17.498"
                height="2.1"
                rx="1.05"
                transform="rotate(-45.74 0 12.532)"
                fill="currentColor"
                fillOpacity=".7"
              />
              <rect
                x="12.531"
                y="13.914"
                width="17.498"
                height="2.1"
                rx="1.05"
                transform="rotate(-135.74 12.531 13.914)"
                fill="currentColor"
                fillOpacity=".7"
              />
            </svg>
          </button>
        </div>
      )}

      {/* ✅ Login Form */}
      <form
        onSubmit={handleSubmit}
        className="sm:w-[350px] w-full text-center border border-gray-300/60 rounded-2xl px-8 bg-white mx-auto"
        aria-label="Login Form"
      >
        <h1 className="text-gray-900 text-3xl mt-10 font-medium">Login</h1>
        <p className="text-gray-500 text-sm mt-2">Please login to continue</p>

        <div className="mt-4">
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded-full px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-400"
            required
          />
        </div>

        <div className="mt-4">
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded-full px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-400"
            required
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="mt-6 w-full py-2 bg-indigo-500 text-white rounded-full hover:bg-indigo-600 transition disabled:opacity-50"
        >
          {loading ? "Logging in..." : "Login"}
        </button>

        <p className="mt-4 text-gray-500 text-sm">
          Don’t have an account?{" "}
          <a href="/signup" className="text-indigo-500 hover:underline">
            Sign Up
          </a>
        </p>
      </form>
    </div>
  );
};

export default Login;
