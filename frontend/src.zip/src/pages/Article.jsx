import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";

export default function Article() {
  const [blogs, setBlogs] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState("");

  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  // Fetch blogs from backend
  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const res = await axios.get(`${API_URL}/api/blogs`);
        // Make sure data is always an array
        const blogsData = Array.isArray(res.data.blogs)
          ? res.data.blogs
          : Array.isArray(res.data)
          ? res.data
          : [];
        setBlogs(blogsData);
        setFiltered(blogsData);
      } catch (err) {
        console.error("Error fetching blogs:", err);
        setBlogs([]);
        setFiltered([]);
      }
    };
    fetchBlogs();
  }, []);

  // Search filter
  useEffect(() => {
    const results = blogs.filter((blog) =>
      blog.title.toLowerCase().includes(search.toLowerCase())
    );
    setFiltered(results);
  }, [search, blogs]);

  return (
    <>
    <Navbar/>
    <section className="min-h-screen bg-gray-50 text-gray-800 px-6 md:px-16 lg:px-32 py-20">
      <h1 className="text-4xl font-bold text-center mb-8 text-gray-900">
        📝 Latest Blog Articles
      </h1>

      {/* Search Input */}
      <div className="max-w-md mx-auto mb-10">
        <input
          type="text"
          placeholder="Search articles..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
        />
      </div>

      {/* Blog Cards */}
      {filtered.length === 0 ? (
        <p className="text-center text-gray-600">No articles found.</p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((blog) => (
            <Link
              key={blog._id}
              to={`/article/${blog._id}`}
              className="block bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-lg transition transform hover:scale-105"
            >
              {blog.featuredImage && (
                <img
                  src={blog.featuredImage}
                  alt={blog.title}
                  className="w-full h-52 object-cover"
                />
              )}
              <div className="p-5">
                <h2 className="text-xl font-semibold mb-2">{blog.title}</h2>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                  {blog.content || "No content available."}
                </p>
                <div className="flex justify-between items-center text-sm text-gray-500">
                  <span>By {blog.userId?.name || "Anonymous"}</span>
                  <span>{new Date(blog.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </section>
    </>
  );
}
