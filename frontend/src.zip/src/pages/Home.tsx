import React from "react";
import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import Footer from "../components/Footer";
import Testimonials from "../components/Testimonials";
import Carousel from "../components/Carousel";

export default function Home() {
  return (
   <>
   <Navbar/>
   <Hero/>
   <Testimonials/>
     <Carousel/>
   <Footer/>

   </>
  );
}
